// Add your Supabase project values here after creating a project.
const SUPABASE_URL = "YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_KEY";
const configured = !SUPABASE_URL.startsWith("YOUR_");
const supabaseClient = configured ? supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const demoJobs = [
 {title:"Virtual Assistant",company:"Remote Client",category:"Freelance",location:"Remote",pay:"Negotiable",description:"Admin support, research, email and scheduling."},
 {title:"Data Entry Assistant",company:"Remote Employer",category:"Data Entry",location:"Remote",pay:"Hourly",description:"Accurate data entry and spreadsheet work."},
 {title:"Social Media Assistant",company:"Small Business",category:"Marketing",location:"Remote",pay:"Project based",description:"Create posts, captions and basic content schedules."},
 {title:"Content Writer",company:"Online Publisher",category:"Writing",location:"Remote",pay:"Per article",description:"Write clear web articles and product content."}
];

const grid = document.getElementById("jobGrid");
function renderJobs(list){
 grid.innerHTML = list.map(j=>`<article class="card">
 <span class="eyebrow">${j.category}</span><h3>${escapeHtml(j.title)}</h3>
 <p><strong>${escapeHtml(j.company)}</strong> · ${escapeHtml(j.location)}</p>
 <div class="job-meta"><span class="tag">${escapeHtml(j.pay)}</span><span class="tag">Kenya-friendly</span></div>
 <p>${escapeHtml(j.description)}</p><a href="#auth">Apply / Save →</a></article>`).join("");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
renderJobs(demoJobs);

document.getElementById("search").addEventListener("input", e=>{
 const q=e.target.value.toLowerCase();
 renderJobs(demoJobs.filter(j=>Object.values(j).join(" ").toLowerCase().includes(q)));
});

const modal=document.getElementById("modal");
function openAuth(){modal.classList.remove("hidden")}
document.getElementById("authBtn").onclick=openAuth;
document.getElementById("heroAuth").onclick=openAuth;
document.getElementById("ctaAuth").onclick=openAuth;
document.getElementById("close").onclick=()=>modal.classList.add("hidden");

document.getElementById("signup").onclick=async()=>{
 const email=document.getElementById("email").value.trim(), password=document.getElementById("password").value;
 const msg=document.getElementById("authMsg");
 if(!configured){msg.textContent="Demo mode: add Supabase credentials in app.js to enable accounts.";return;}
 const {error}=await supabaseClient.auth.signUp({email,password});
 msg.textContent=error?error.message:"Account created. Check your email if confirmation is enabled.";
};
document.getElementById("login").onclick=async()=>{
 const email=document.getElementById("email").value.trim(), password=document.getElementById("password").value;
 const msg=document.getElementById("authMsg");
 if(!configured){msg.textContent="Demo mode: connect Supabase first.";return;}
 const {error}=await supabaseClient.auth.signInWithPassword({email,password});
 msg.textContent=error?error.message:"Logged in successfully.";
};