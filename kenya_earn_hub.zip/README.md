# Kenya Earn Hub 🇰🇪

A mobile-first online jobs + affiliate-earning website starter.

## Included
- Responsive homepage
- Jobs directory and search
- Supabase authentication hooks
- PostgreSQL schema for jobs, profiles and saved jobs
- Affiliate URL field
- Admin-ready database structure
- M-Pesa integration notes

## Setup

1. Create a Supabase project.
2. Open SQL Editor and run `supabase_schema.sql`.
3. Copy your Supabase project URL and publishable/anon key.
4. Put them in `app.js`:
   `SUPABASE_URL`
   `SUPABASE_ANON_KEY`
5. Open `index.html` in a browser or deploy the folder to a static host.

Supabase's browser client supports authentication and database access. Keep privileged/service-role credentials off the client.

## M-Pesa

Do NOT put Daraja consumer secrets in `app.js`.
Create a backend endpoint/serverless function for payment requests and callbacks.

Recommended flow:
Browser -> your backend -> Safaricom Daraja -> callback -> database.

For production, configure your Daraja app and credentials in server-side environment variables.

## Next production features
- Admin login and protected dashboard
- Add/edit/delete jobs
- Real affiliate tracking
- User profiles
- Saved jobs
- Paid featured listings
- M-Pesa checkout
- Email notifications
- Analytics
