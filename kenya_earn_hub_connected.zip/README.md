# Kenya Earn Hub — Ready-to-connect business website

## What is complete
- Mobile-first public website
- Jobs search and cards
- Account UI wired for Supabase Auth
- Database schema with Row Level Security
- Affiliate offer slots
- Disclosure and scam-safety messaging
- Admin dashboard shell
- Monetization plan: affiliate referrals, sponsored/featured jobs, digital products, optional paid services

## What you must connect
1. A Supabase project: copy the project URL + **publishable key** into `app.js`.
2. Run `supabase_schema.sql` in Supabase SQL Editor.
3. Replace the three placeholder affiliate URLs with referral URLs from programs you are actually approved for.
4. Deploy the folder to a web host and connect a domain if desired.
5. For M-Pesa, create a server/Edge Function. Put Safaricom credentials in server-side environment variables, never in `app.js`.
6. Before charging users, publish Terms, Privacy, Refund/Payment and Affiliate Disclosure pages.

## Security
Supabase's current guidance says publishable keys can be exposed in browser code when Row Level Security is correctly configured, while secret keys must remain on a backend. Do not put a secret/service-role key in this project.

## How this makes money
- Affiliate commissions when visitors complete qualifying actions through your approved links.
- Paid featured job listings from legitimate employers.
- Sponsored educational content.
- Digital products such as CV templates, job-search guides and beginner courses.
- Later: paid employer accounts.

Never advertise guaranteed income or guaranteed employment.

## M-Pesa production flow
Website -> server/Edge Function -> Safaricom Daraja -> callback -> database/order status -> user confirmation.

Use Daraja sandbox first, then production credentials after testing.

## Deployment
This is a static front end and can be deployed on any static hosting service. The Supabase connection and M-Pesa backend are the parts that need your accounts and credentials.


## Security
The public Supabase URL and publishable key are connected in app.js. No secret/service-role key is stored in the website. Rotate/revoke any Supabase secret that was exposed during setup before production. Keep replacement secrets only on a server/Edge Function.
