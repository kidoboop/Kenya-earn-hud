const CONFIG={
 SUPABASE_URL:"YOUR_SUPABASE_URL",
 SUPABASE_PUBLISHABLE_KEY:"YOUR_SUPABASE_PUBLISHABLE_KEY",
 AFFILIATE_URLS:{
  1:"https://example.com/replace-with-your-approved-affiliate-link-1",
  2:"https://example.com/replace-with-your-approved-affiliate-link-2",
  3:"https://example.com/replace-with-your-approved-affiliate-link-3"
 }
};
const configured=!CONFIG.SUPABASE_URL.startsWith("YOUR_");
const sb=configured?supabase.createClient(CONFIG.SUPABASE_URL,CONFIG.SUPABASE_PUBLISHABLE_KEY):null;
const demoJobs=[
 {title:"Virtual Assistant",company:"Remote Client",category:"Freelance",location:"Remote",pay:"Negotiable",description:"Admin support, research, email and scheduling."},
 {title:"Data Entry Assistant",company:"Remote Employer",category:"Data Entry",location:"Remote",pay:"Hourly",description:"Accurate data entry and spreadsheet work."},
 {title:"Social Media Assistant",company:"Small Business",category:"Marketing",location:"Remote",pay:"Project based",description:"Create posts, captions and content schedules."},
 {title:"Content Writer",company:"Online Publisher",category:"Writing",location:"Remote",pay:"Per article",description:"Write clear web articles and product content."}
];
const grid=document.querySelector("#jobGrid");
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
function render(list){grid.innerHTML=list.map(j=>`<article class="card"><span class="eyebrow">${esc(j.category)}</span><h3>${esc(j.title)}</h3><p><strong>${esc(j.company)}</strong> · ${esc(j.location)}</p><div class="job-meta"><span class="tag">${esc(j.pay)}</span><span class="tag">Kenya-friendly</span></div><p>${esc(j.description)}</p><a href="#account" class="save">Save / apply →</a></article>`).join("")}
render(demoJobs);
document.querySelector("#search").addEventListener("input",e=>{const q=e.target.value.toLowerCase();render(demoJobs.filter(j=>Object.values(j).join(" ").toLowerCase().includes(q)))});
const modal=document.querySelector("#modal"); const open=()=>modal.classList.remove("hidden"); const close=()=>modal.classList.add("hidden");
["authBtn","heroAuth","ctaAuth"].forEach(id=>document.getElementById(id).onclick=open); document.getElementById("close").onclick=close;
document.querySelectorAll("[data-affiliate]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();const u=CONFIG.AFFILIATE_URLS[a.dataset.affiliate]; if(!u||u.includes("example.com")){alert("Add your approved affiliate URL in app.js first.");return} window.open(u,"_blank","noopener")}));
async function auth(mode){const email=document.querySelector("#email").value.trim(),password=document.querySelector("#password").value,msg=document.querySelector("#authMsg");if(!configured){msg.textContent="Demo mode. Add your Supabase URL and publishable key to enable accounts.";return}let r=mode==="signup"?await sb.auth.signUp({email,password}):await sb.auth.signInWithPassword({email,password});msg.textContent=r.error?r.error.message:(mode==="signup"?"Account created. Check your email if confirmation is enabled.":"Logged in successfully.");}
document.querySelector("#signup").onclick=()=>auth("signup");document.querySelector("#login").onclick=()=>auth("login");